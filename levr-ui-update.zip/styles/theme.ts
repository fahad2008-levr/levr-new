export const colors = {
  primary: {
    main: "#002BFF",
    light: "#E8F0F9",
  },
  secondary: {
    main: "#3EFFA7",
    light: "#00F9FF",
  },
  grey: {
    100: "#9B9B9B",
    200: "#303030",
    300: "#0A0A0A",
  },
  white: "#FFFFFF",
  black: "#000000",
}

export const fonts = {
  heading: 'Nebulica, "Noto Kufi Arabic", sans-serif',
  body: 'Manrope, "Noto Kufi Arabic", sans-serif',
}

export const fontSizes = {
  xs: "0.75rem",
  sm: "0.875rem",
  md: "1rem",
  lg: "1.125rem",
  xl: "1.25rem",
  "2xl": "1.5rem",
  "3xl": "1.875rem",
  "4xl": "2.25rem",
  "5xl": "3rem",
}

export const spacing = {
  xs: "0.25rem",
  sm: "0.5rem",
  md: "1rem",
  lg: "1.5rem",
  xl: "2rem",
  "2xl": "3rem",
  "3xl": "4rem",
}

export const borderRadius = {
  sm: "0.25rem",
  md: "0.5rem",
  lg: "1rem",
  full: "9999px",
}

