import bcrypt from "bcryptjs"
import { v4 as uuidv4 } from "uuid"

export async function sendVerificationEmail(email: string, token: string) {
  // In production, this would use a proper email service
  console.log(`Sending verification email to ${email} with token ${token}`)
  return {
    success: true,
    message: "Verification email sent successfully",
  }
}

export function generateVerificationCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

export const ROLES = {
  DEVELOPER: {
    title: "مطور",
    options: [
      { id: "frontend", label: "مطور واجهة أمامية" },
      { id: "backend", label: "مطور خلفية" },
      { id: "support", label: "دعم فني" },
      { id: "admin", label: "إداري" },
    ],
  },
  SCHOOL: {
    title: "موظف مدرسة",
    options: [
      { id: "teacher", label: "معلم" },
      { id: "admin", label: "إداري" },
      { id: "principal", label: "مدير" },
    ],
  },
  STUDENT: {
    title: "طالب",
    levels: [
      { id: "kindergarten", label: "روضة" },
      { id: "primary", label: "ابتدائي" },
      { id: "secondary", label: "ثانوي" },
    ],
  },
}

export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(12)
  return bcrypt.hash(password, salt)
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword)
}

export function generateVerificationToken(): string {
  return uuidv4()
}

export function isStrongPassword(password: string): boolean {
  const minLength = 8
  const hasUpperCase = /[A-Z]/.test(password)
  const hasLowerCase = /[a-z]/.test(password)
  const hasNumbers = /\d/.test(password)
  const hasNonalphas = /\W/.test(password)
  return password.length >= minLength && hasUpperCase && hasLowerCase && hasNumbers && hasNonalphas
}

