"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { School, Users, Bell, Settings, TrendingUp } from "lucide-react"
import { colors, fonts, fontSizes, spacing, borderRadius } from "@/styles/theme"

export default function DeveloperDashboard() {
  const router = useRouter()

  const stats = [
    { title: "إجمالي المدارس", value: 25, icon: School, color: "blue" },
    { title: "إجمالي الطلاب", value: 1234, icon: Users, color: "green" },
    { title: "التنبيهات النشطة", value: 8, icon: Bell, color: "yellow" },
    { title: "إعدادات النظام", value: 5, icon: Settings, color: "purple" },
  ]

  const quickActions = [
    { title: "إدارة المدارس", icon: School, href: "/dashboard/developer/schools", color: "blue" },
    { title: "إدارة المستخدمين", icon: Users, href: "/dashboard/developer/users", color: "green" },
    { title: "تعديل إعدادات النظام", icon: Settings, href: "/dashboard/developer/settings", color: "purple" },
  ]

  const recentUpdates = [
    { message: "تم إضافة مدرسة جديدة: مدرسة الأمل", color: "blue" },
    { message: "تحديث نظام إدارة الطلاب", color: "green" },
    { message: "إشعار صيانة مجدولة: الجمعة القادمة", color: "yellow" },
  ]

  return (
    <div className="space-y-6 p-6" style={{ fontFamily: fonts.body }}>
      <div className="space-y-1">
        <h2 className="text-3xl font-semibold" style={{ fontFamily: fonts.heading, color: colors.primary.main }}>
          لوحة المعلومات الرئيسية
        </h2>
        <p className="text-gray-600">نظرة عامة على النظام</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <Card
            key={index}
            className="bg-white border-0 shadow-sm hover:shadow-md transition-all duration-300"
            style={{ borderRadius: borderRadius.lg }}
          >
            <CardContent className="p-6 space-y-2">
              <div className="flex items-center gap-2">
                <stat.icon className={`h-5 w-5 text-${stat.color}-600`} />
                <h3 className="text-lg font-medium text-gray-800">{stat.title}</h3>
              </div>
              <div className="flex flex-col">
                <span className="text-3xl font-bold text-gray-900">{stat.value}</span>
                <span className="text-sm text-gray-600">+2 منذ آخر شهر</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card
          className="bg-white border-0 shadow-sm hover:shadow-md transition-all duration-300"
          style={{ borderRadius: borderRadius.lg }}
        >
          <CardHeader>
            <CardTitle className="text-xl font-semibold" style={{ color: colors.primary.main }}>
              الإجراءات السريعة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {quickActions.map((action, index) => (
                <Button
                  key={index}
                  className="w-full justify-start"
                  variant="outline"
                  onClick={() => router.push(action.href)}
                  style={{ borderRadius: borderRadius.md }}
                >
                  <action.icon className={`mr-2 h-4 w-4 text-${action.color}-600`} />
                  {action.title}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card
          className="bg-white border-0 shadow-sm hover:shadow-md transition-all duration-300"
          style={{ borderRadius: borderRadius.lg }}
        >
          <CardHeader>
            <CardTitle className="text-xl font-semibold" style={{ color: colors.primary.main }}>
              آخر التحديثات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {recentUpdates.map((update, index) => (
                <li key={index} className={`flex items-center gap-3 p-3 bg-${update.color}-50 rounded-lg`}>
                  <span className={`w-2 h-2 bg-${update.color}-500 rounded-full`}></span>
                  <span className="text-gray-700">{update.message}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

