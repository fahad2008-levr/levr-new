"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { VerificationCode } from "@/components/auth/verification-code"
import { colors, fonts, fontSizes, spacing, borderRadius } from "@/styles/theme"
import { toast } from "sonner"
import { sendVerificationEmail, verifyPassword, isStrongPassword, hashPassword } from "@/utils/verification"

// Mock data for schools and students
const SCHOOLS = [
  { id: "1", name: "مدرسة النور للاحتياجات الخاصة" },
  { id: "2", name: "مدرسة الأمل للاحتياجات الخاصة" },
  { id: "3", name: "مدرسة السلام للاحتياجات الخاصة" },
]

const STUDENTS = {
  "1": [
    { id: "101", name: "أحمد محمد" },
    { id: "102", name: "فاطمة علي" },
  ],
  "2": [
    { id: "201", name: "عمر خالد" },
    { id: "202", name: "نورة سعيد" },
  ],
  "3": [
    { id: "301", name: "سارة أحمد" },
    { id: "302", name: "يوسف محمود" },
  ],
}

export default function StudentLogin() {
  const [step, setStep] = useState<"school" | "student" | "guardian" | "verification" | "password" | "login">("school")
  const [schoolId, setSchoolId] = useState("")
  const [studentId, setStudentId] = useState("")
  const [guardianPhone, setGuardianPhone] = useState("")
  const [guardianEmail, setGuardianEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const router = useRouter()

  const handleSchoolSelect = (value: string) => {
    setSchoolId(value)
    setStep("student")
  }

  const handleStudentSelect = (value: string) => {
    setStudentId(value)
    setStep("guardian")
  }

  const handleGuardianSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!guardianPhone || !guardianEmail) {
      setError("الرجاء إدخال رقم الهاتف والبريد الإلكتروني لولي الأمر")
      return
    }

    try {
      const result = await sendVerificationEmail(guardianEmail, "generatedToken")
      if (result.success) {
        setStep("verification")
        toast.success("تم إرسال رمز التحقق إلى البريد الإلكتروني لولي الأمر")
      } else {
        setError("حدث خطأ أثناء إرسال رمز التحقق")
      }
    } catch (error) {
      setError("حدث خطأ أثناء إرسال رمز التحقق")
    }
  }

  const handleVerification = async (token: string) => {
    try {
      // In production, verify the token with your API
      console.log("Verifying token:", token)
      setStep("password")
    } catch (error) {
      toast.error("رمز التحقق غير صحيح")
    }
  }

  const handlePasswordSetup = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!isStrongPassword(password)) {
      setError("كلمة المرور ضعيفة. يجب أن تحتوي على 8 أحرف على الأقل، وتتضمن أحرف كبيرة وصغيرة وأرقام ورموز")
      return
    }

    try {
      // In production, save the hashed password securely
      const hashedPassword = await hashPassword(password)
      console.log("Hashed password:", hashedPassword) // In production, save this to your database
      toast.success("تم إنشاء كلمة المرور بنجاح")
      router.push("/dashboard/student")
    } catch (error) {
      setError("حدث خطأ أثناء إنشاء كلمة المرور")
    }
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!guardianEmail || !password) {
      setError("الرجاء إدخال البريد الإلكتروني وكلمة المرور")
      return
    }

    try {
      // In production, verify credentials with your API
      // For demonstration, we're using a mock hashed password
      const mockHashedPassword = "$2a$12$k8H.pxWVQbDiNrLE4nkQWOhHGGGhzcWwJQJKbHgwGpZg7yWuSH3yW" // hashed version of "password123"
      const isValidPassword = await verifyPassword(password, mockHashedPassword)
      if (isValidPassword) {
        toast.success("تم تسجيل الدخول بنجاح")
        router.push("/dashboard/student")
      } else {
        setError("البريد الإلكتروني أو كلمة المرور غير صحيحة")
      }
    } catch (error) {
      setError("حدث خطأ أثناء تسجيل الدخول")
    }
  }

  const handleForgotPassword = () => {
    router.push("/auth/reset-password")
  }

  const renderStep = () => {
    switch (step) {
      case "school":
        return (
          <>
            <CardHeader>
              <CardTitle>اختر المدرسة</CardTitle>
              <CardDescription>حدد المدرسة التي تنتمي إليها</CardDescription>
            </CardHeader>
            <CardContent>
              <Select onValueChange={handleSchoolSelect}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر المدرسة" />
                </SelectTrigger>
                <SelectContent>
                  {SCHOOLS.map((school) => (
                    <SelectItem key={school.id} value={school.id}>
                      {school.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </>
        )
      case "student":
        return (
          <>
            <CardHeader>
              <CardTitle>اختر الطالب</CardTitle>
              <CardDescription>حدد اسم الطالب</CardDescription>
            </CardHeader>
            <CardContent>
              <Select onValueChange={handleStudentSelect}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر الطالب" />
                </SelectTrigger>
                <SelectContent>
                  {STUDENTS[schoolId as keyof typeof STUDENTS].map((student) => (
                    <SelectItem key={student.id} value={student.id}>
                      {student.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </>
        )
      case "guardian":
        return (
          <>
            <CardHeader>
              <CardTitle>معلومات ولي الأمر</CardTitle>
              <CardDescription>أدخل معلومات الاتصال بولي الأمر</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleGuardianSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="guardianPhone">رقم هاتف ولي الأمر</Label>
                  <Input
                    id="guardianPhone"
                    type="tel"
                    value={guardianPhone}
                    onChange={(e) => setGuardianPhone(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="guardianEmail">البريد الإلكتروني لولي الأمر</Label>
                  <Input
                    id="guardianEmail"
                    type="email"
                    value={guardianEmail}
                    onChange={(e) => setGuardianEmail(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full">
                  إرسال رمز التحقق
                </Button>
              </form>
            </CardContent>
          </>
        )
      case "verification":
        return (
          <VerificationCode
            email={guardianEmail}
            onVerify={handleVerification}
            onResend={() => handleGuardianSubmit}
            onBack={() => setStep("guardian")}
          />
        )
      case "password":
        return (
          <>
            <CardHeader>
              <CardTitle>إنشاء كلمة المرور</CardTitle>
              <CardDescription>قم بإنشاء كلمة مرور قوية لحسابك</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePasswordSetup} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="password">كلمة المرور الجديدة</Label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full">
                  حفظ كلمة المرور
                </Button>
              </form>
            </CardContent>
          </>
        )
      case "login":
        return (
          <>
            <CardHeader>
              <CardTitle>تسجيل دخول الطالب</CardTitle>
              <CardDescription>أدخل بريدك الإلكتروني وكلمة المرور للوصول إلى ملفك الشخصي</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">البريد الإلكتروني</Label>
                  <Input
                    id="email"
                    type="email"
                    value={guardianEmail}
                    onChange={(e) => setGuardianEmail(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">كلمة المرور</Label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>خطأ</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                <Button type="submit" className="w-full">
                  تسجيل الدخول
                </Button>
              </form>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Button variant="link" onClick={handleForgotPassword}>
                نسيت كلمة المرور؟
              </Button>
            </CardFooter>
          </>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light to-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-0 shadow-lg">
        {renderStep()}
        {step !== "login" && (
          <CardFooter className="flex justify-center">
            <Button variant="link" onClick={() => setStep("login")}>
              لديك حساب بالفعل؟ تسجيل الدخول
            </Button>
          </CardFooter>
        )}
      </Card>
    </div>
  )
}

