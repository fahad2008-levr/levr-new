"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { VerificationCode } from "@/components/auth/verification-code"
import { SocialLogin } from "@/components/auth/social-login"
import { ROLES } from "@/utils/verification"
import { toast } from "sonner"

// Mock data
const SCHOOLS = [
  { id: "1", name: "مدرسة النور للاحتياجات الخاصة" },
  { id: "2", name: "مدرسة الأمل للاحتياجات الخاصة" },
  { id: "3", name: "مدرسة السلام للاحتياجات الخاصة" },
]

const CLASSES = {
  kindergarten: ["KG1", "KG2", "KG3"],
  primary: ["الصف الأول", "الصف الثاني", "الصف الثالث", "الصف الرابع", "الصف الخامس", "الصف السادس"],
  secondary: ["الصف الأول الثانوي", "الصف الثاني الثانوي", "الصف الثالث الثانوي"],
}

export default function StudentRegister() {
  const router = useRouter()
  const [step, setStep] = useState<"form" | "verification">("form")
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    schoolId: "",
    level: "",
    class: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      console.log("Form data:", formData)
      setStep("verification")
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء الحساب")
    }
  }

  const handleVerification = async (code: string) => {
    try {
      console.log("Verification code:", code)
      toast.success("تم التحقق من الحساب بنجاح")
      router.push("/dashboard/student")
    } catch (error) {
      toast.error("رمز التحقق غير صحيح")
    }
  }

  if (step === "verification") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary-light to-white flex items-center justify-center p-4">
        <VerificationCode
          email={formData.email}
          onVerify={handleVerification}
          onResend={() => toast.success("تم إرسال رمز جديد")}
          onBack={() => setStep("form")}
        />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light to-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-0 shadow-lg">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl">إنشاء حساب طالب</CardTitle>
          <CardDescription>أدخل بياناتك للانضمام إلى المدرسة</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">الاسم الأول</Label>
                <Input
                  id="firstName"
                  placeholder="محمد"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">الاسم الأخير</Label>
                <Input
                  id="lastName"
                  placeholder="أحمد"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input
                id="email"
                type="email"
                placeholder="example@google.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">رقم الجوال</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="05xxxxxxxx"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="school">المدرسة</Label>
              <Select
                value={formData.schoolId}
                onValueChange={(value) => setFormData({ ...formData, schoolId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر المدرسة" />
                </SelectTrigger>
                <SelectContent>
                  {SCHOOLS.map((school) => (
                    <SelectItem key={school.id} value={school.id}>
                      {school.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="level">المرحلة الدراسية</Label>
              <Select
                value={formData.level}
                onValueChange={(value) => setFormData({ ...formData, level: value, class: "" })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر المرحلة الدراسية" />
                </SelectTrigger>
                <SelectContent>
                  {ROLES.STUDENT.levels.map((level) => (
                    <SelectItem key={level.id} value={level.id}>
                      {level.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {formData.level && (
              <div className="space-y-2">
                <Label htmlFor="class">الصف</Label>
                <Select value={formData.class} onValueChange={(value) => setFormData({ ...formData, class: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر الصف" />
                  </SelectTrigger>
                  <SelectContent>
                    {CLASSES[formData.level as keyof typeof CLASSES].map((className) => (
                      <SelectItem key={className} value={className}>
                        {className}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <Button type="submit" className="w-full">
              إنشاء الحساب
            </Button>
          </form>

          <SocialLogin
            onGoogleLogin={() => toast.info("قريباً - تسجيل الدخول عبر Google")}
            onAppleLogin={() => toast.info("قريباً - تسجيل الدخول عبر Apple")}
          />
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button variant="link" onClick={() => router.push("/auth/student/login")}>
            لديك حساب بالفعل؟ تسجيل الدخول
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

