"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { VerificationCode } from "@/components/auth/verification-code"
import { SocialLogin } from "@/components/auth/social-login"
import { colors, fonts, fontSizes, spacing, borderRadius } from "@/styles/theme"
import { toast } from "sonner"
import { sendVerificationEmail, verifyPassword, isStrongPassword } from "@/utils/verification"

export default function SchoolLogin() {
  const [step, setStep] = useState<"form" | "verification">("form")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!email || !password) {
      setError("الرجاء إدخال البريد الإلكتروني وكلمة المرور")
      return
    }

    try {
      // In production, this would call your API for authentication
      // For demonstration, we're using a mock hashed password
      const mockHashedPassword = "$2a$12$k8H.pxWVQbDiNrLE4nkQWOhHGGGhzcWwJQJKbHgwGpZg7yWuSH3yW" // hashed version of "password123"
      const isValidPassword = await verifyPassword(password, mockHashedPassword)
      if (isValidPassword) {
        toast.success("تم تسجيل الدخول بنجاح")
        router.push("/dashboard/school")
      } else {
        setError("البريد الإلكتروني أو كلمة المرور غير صحيحة")
      }
    } catch (error) {
      setError("حدث خطأ أثناء تسجيل الدخول")
    }
  }

  const handleVerification = async (token: string) => {
    try {
      // In production, this would verify the token with your API
      console.log("Verifying token:", token)
      toast.success("تم التحقق بنجاح")
      router.push("/dashboard/school")
    } catch (error) {
      toast.error("رمز التحقق غير صحيح")
    }
  }

  const handleForgotPassword = () => {
    router.push("/auth/reset-password")
  }

  const handleSendVerificationEmail = async () => {
    if (!email) {
      setError("الرجاء إدخال البريد الإلكتروني")
      return
    }

    try {
      const result = await sendVerificationEmail(email, "generatedToken")
      if (result.success) {
        setStep("verification")
      } else {
        setError("حدث خطأ أثناء إرسال رمز التحقق")
      }
    } catch (error) {
      setError("حدث خطأ أثناء إرسال رمز التحقق")
    }
  }

  if (step === "verification") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary-light to-white flex items-center justify-center p-4">
        <VerificationCode
          email={email}
          onVerify={handleVerification}
          onResend={handleSendVerificationEmail}
          onBack={() => setStep("form")}
        />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light to-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-0 shadow-lg">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl">تسجيل دخول المدرسة</CardTitle>
          <CardDescription>أدخل بريدك الإلكتروني للوصول إلى لوحة تحكم المدرسة</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input
                id="email"
                type="email"
                placeholder="example@domain.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>خطأ</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button type="submit" className="w-full">
              تسجيل الدخول
            </Button>
          </form>

          <div className="mt-4">
            <Button variant="outline" onClick={handleSendVerificationEmail} className="w-full">
              تسجيل الدخول باستخدام رمز التحقق
            </Button>
          </div>

          <SocialLogin onGoogleLogin={() => toast.info("قريباً - تسجيل الدخول عبر Google")} />
        </CardContent>
        <CardFooter className="flex flex-col gap-4 items-center">
          <Button variant="link" onClick={handleForgotPassword}>
            نسيت كلمة المرور؟
          </Button>
          <Button variant="link" onClick={() => router.push("/auth/school/register")}>
            ليس لديك حساب؟ إنشاء حساب جديد
          </Button>
          <Button variant="link" onClick={() => router.push("/")}>
            العودة إلى الصفحة الرئيسية
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

