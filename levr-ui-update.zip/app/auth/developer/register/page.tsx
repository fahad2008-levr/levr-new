"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { VerificationCode } from "@/components/auth/verification-code"
import { SocialLogin } from "@/components/auth/social-login"
import { ROLES } from "@/utils/verification"
import { toast } from "sonner"

export default function DeveloperRegister() {
  const router = useRouter()
  const [step, setStep] = useState<"form" | "verification">("form")
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    role: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      // In production, this would call your API
      console.log("Form data:", formData)
      setStep("verification")
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء الحساب")
    }
  }

  const handleVerification = async (code: string) => {
    try {
      // In production, this would verify the code
      console.log("Verification code:", code)
      toast.success("تم التحقق من الحساب بنجاح")
      router.push("/dashboard/developer")
    } catch (error) {
      toast.error("رمز التحقق غير صحيح")
    }
  }

  if (step === "verification") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary-light to-white flex items-center justify-center p-4">
        <VerificationCode
          email={formData.email}
          onVerify={handleVerification}
          onResend={() => toast.success("تم إرسال رمز جديد")}
          onBack={() => setStep("form")}
        />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light to-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-0 shadow-lg">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl">إنشاء حساب مطور</CardTitle>
          <CardDescription>أدخل بياناتك لإنشاء حساب جديد</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">الاسم الأول</Label>
                <Input
                  id="firstName"
                  placeholder="محمد"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">الاسم الأخير</Label>
                <Input
                  id="lastName"
                  placeholder="أحمد"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input
                id="email"
                type="email"
                placeholder="example@google.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">رقم الجوال</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="05xxxxxxxx"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">المهمة</Label>
              <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر مهمتك" />
                </SelectTrigger>
                <SelectContent>
                  {ROLES.DEVELOPER.options.map((option) => (
                    <SelectItem key={option.id} value={option.id}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button type="submit" className="w-full">
              إنشاء الحساب
            </Button>
          </form>

          <SocialLogin
            onGoogleLogin={() => toast.info("قريباً - تسجيل الدخول عبر Google")}
            onAppleLogin={() => toast.info("قريباً - تسجيل الدخول عبر Apple")}
          />
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button variant="link" onClick={() => router.push("/auth/developer/login")}>
            لديك حساب بالفعل؟ تسجيل الدخول
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

