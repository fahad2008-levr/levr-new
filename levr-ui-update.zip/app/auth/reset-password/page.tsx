"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { toast } from "sonner"

export default function ResetPassword() {
  const [email, setEmail] = useState("")
  const [step, setStep] = useState<"request" | "verify" | "reset">("request")
  const [verificationCode, setVerificationCode] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const router = useRouter()

  const handleRequestReset = (e: React.FormEvent) => {
    e.preventDefault()
    // In production, send a reset password email
    toast.success("تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني")
    setStep("verify")
  }

  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault()
    // In production, verify the code
    if (verificationCode) {
      setStep("reset")
    } else {
      toast.error("الرجاء إدخال رمز التحقق")
    }
  }

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault()
    // In production, reset the password
    if (newPassword) {
      toast.success("تم إعادة تعيين كلمة المرور بنجاح")
      router.push("/auth/login")
    } else {
      toast.error("الرجاء إدخال كلمة المرور الجديدة")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light to-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-0 shadow-lg">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl">إعادة تعيين كلمة المرور</CardTitle>
          <CardDescription>
            {step === "request" && "أدخل بريدك الإلكتروني لإعادة تعيين كلمة المرور"}
            {step === "verify" && "أدخل رمز التحقق الذي تم إرساله إلى بريدك الإلكتروني"}
            {step === "reset" && "أدخل كلمة المرور الجديدة"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {step === "request" && (
            <form onSubmit={handleRequestReset} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">البريد الإلكتروني</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="example@domain.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                إرسال رابط إعادة التعيين
              </Button>
            </form>
          )}

          {step === "verify" && (
            <form onSubmit={handleVerifyCode} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="verificationCode">رمز التحقق</Label>
                <Input
                  id="verificationCode"
                  type="text"
                  placeholder="أدخل رمز التحقق"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                التحقق من الرمز
              </Button>
            </form>
          )}

          {step === "reset" && (
            <form onSubmit={handleResetPassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="newPassword">كلمة المرور الجديدة</Label>
                <Input
                  id="newPassword"
                  type="password"
                  placeholder="أدخل كلمة المرور الجديدة"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                إعادة تعيين كلمة المرور
              </Button>
            </form>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button variant="link" onClick={() => router.push("/")}>
            العودة إلى الصفحة الرئيسية
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

