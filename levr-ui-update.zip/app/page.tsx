import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { School, Users, GraduationCap } from "lucide-react"
import { colors, fonts, fontSizes, spacing, borderRadius } from "@/styles/theme"

export default function HomePage() {
  return (
    <div
      className="min-h-screen bg-gradient-to-br from-primary-light to-white flex flex-col items-center justify-center p-4"
      style={{ fontFamily: fonts.body }}
    >
      <div className="w-full max-w-4xl">
        <div className="text-center mb-12 space-y-4">
          <h1
            className="text-5xl font-bold tracking-tight"
            style={{ fontFamily: fonts.heading, color: colors.primary.main }}
          >
            نظام إدارة الطلاب ذوي الاحتياجات الخاصة
          </h1>
          <p className="text-xl text-gray-600">منصة متكاملة لإدارة ومشاركة بيانات الطلاب في حالات الطوارئ</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              title: "دخول المطورين",
              description: "لوحة تحكم إدارة النظام والمدارس",
              icon: Users,
              color: "blue",
              href: "/auth/developer/login", // Updated
            },
            {
              title: "دخول المدرسة",
              description: "إدارة وتتبع الطلاب والفصول الدراسية",
              icon: School,
              color: "green",
              href: "/auth/school/login", // Updated
            },
            {
              title: "دخول الطالب",
              description: "الوصول إلى الملف الشخصي والمعلومات",
              icon: GraduationCap,
              color: "purple",
              href: "/auth/student/login", // Updated
            },
          ].map((item, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300"
              style={{ borderRadius: borderRadius.lg }}
            >
              <CardHeader>
                <div className="flex justify-center mb-4">
                  <div className={`p-3 bg-${item.color}-100 rounded-full`}>
                    <item.icon className={`w-8 h-8 text-${item.color}-600`} />
                  </div>
                </div>
                <CardTitle className="text-center text-xl font-semibold">{item.title}</CardTitle>
                <CardDescription className="text-center">{item.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  asChild
                  className="w-full"
                  style={{ backgroundColor: colors.primary.main, borderRadius: borderRadius.md }}
                >
                  <Link href={item.href}>تسجيل الدخول</Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center text-gray-500 text-sm">جميع الحقوق محفوظة © {new Date().getFullYear()}</div>
      </div>
    </div>
  )
}

