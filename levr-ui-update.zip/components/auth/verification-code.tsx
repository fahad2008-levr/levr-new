"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { ArrowLeft, Mail } from "lucide-react"
import { colors } from "@/styles/theme"
import { Label } from "@/components/ui/label"

interface VerificationCodeProps {
  email: string
  onVerify: (token: string) => void
  onResend: () => void
  onBack: () => void
}

export function VerificationCode({ email, onVerify, onResend, onBack }: VerificationCodeProps) {
  const [token, setToken] = useState("")
  const [timer, setTimer] = useState(60)
  const [isResending, setIsResending] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setTimer((prev) => (prev > 0 ? prev - 1 : 0))
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setToken(e.target.value)
  }

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    //This function is no longer needed with the updated form
  }

  const handleResend = async () => {
    setIsResending(true)
    await onResend()
    setTimer(60)
    setIsResending(false)
  }

  return (
    <Card className="w-full max-w-md border-0 shadow-lg">
      <CardHeader className="space-y-1">
        <Button variant="ghost" className="w-fit h-fit p-0 mb-4" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 ml-2" />
          رجوع
        </Button>
        <CardTitle className="text-2xl">التحقق من البريد الإلكتروني</CardTitle>
        <CardDescription className="flex items-center gap-2">
          <Mail className="h-4 w-4" />
          تم إرسال رمز التحقق إلى {email}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form
          onSubmit={(e) => {
            e.preventDefault()
            onVerify(token)
          }}
          className="space-y-4"
        >
          <div className="space-y-2">
            <Label htmlFor="token">رمز التحقق</Label>
            <Input
              id="token"
              type="text"
              value={token}
              onChange={handleInputChange}
              placeholder="أدخل رمز التحقق"
              required
            />
          </div>
          <Button type="submit" className="w-full">
            التحقق
          </Button>
        </form>

        <div className="text-center space-y-4">
          <p className="text-sm text-gray-500">
            {timer > 0 ? (
              <>
                يمكنك طلب رمز جديد خلال{" "}
                <span className="font-medium text-primary">
                  {Math.floor(timer / 60)}:{(timer % 60).toString().padStart(2, "0")}
                </span>
              </>
            ) : (
              <Button variant="link" onClick={handleResend} disabled={isResending} className="p-0">
                لم يصلك الرمز؟ اطلب رمزاً جديداً
              </Button>
            )}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

