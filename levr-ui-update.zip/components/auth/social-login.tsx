"use client"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import Image from "next/image"

interface SocialLoginProps {
  onGoogleLogin: () => void
}

export function SocialLogin({ onGoogleLogin }: SocialLoginProps) {
  return (
    <div className="space-y-4">
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <Separator />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-background px-2 text-muted-foreground">أو التسجيل باستخدام</span>
        </div>
      </div>

      {/* Removed Apple login button */}
    </div>
  )
}

